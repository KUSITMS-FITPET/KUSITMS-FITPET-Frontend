
const MainPage = () => {
  return (
    <div>mainpage
    </div>
  );
};

export default MainPage;
